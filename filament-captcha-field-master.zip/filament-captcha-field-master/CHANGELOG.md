# Changelog

All notable changes to `filament-captcha-field` will be documented in this file.

## v.0.1.1 - 2023-02-27

- Allows using Laravel 10.
